// const mongodb = require(mongodb);
// const MongoClient = mongodb.MongoClient;

// let database;

// async function getDatabase() {
//   const client = await MongoClient.connect('mongodb://127.0.0.1:27017');
//   database = client.db('shop');

// if(!database){
//   console.log("Database Not Connected");
// }
// else{
//   console.log("Database Connected");
// }

// return database;

// }

// module.exports = {
//   getDatabase
// }

const { MongoClient, ObjectId } = require('mongodb');

let database;

async function getDatabase() {
  try {
    const client = await MongoClient.connect('mongodb://localhost:27017');
    database = client.db('shop');
    console.log("Database Connected");
    return database;
  } catch (error) {
    console.error('Error connecting to MongoDB:', error);
    throw error;
  }
}

module.exports = {
  getDatabase,
  ObjectId

};
