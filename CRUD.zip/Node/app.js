// Import required modules
const express = require('express');
const exphbs = require('express-handlebars');
const bodyParser = require('body-parser');

// Create an Express application
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


// Set up Handlebars as the view engine
app.engine('hbs', exphbs.engine({ layoutsDir: 'views/', defaultLayout: 'main', extname: 'hbs' }));
app.set('view engine', 'hbs');
app.set('views', 'views');


//Database Connection
const dbo = require('./db');
const { Collection } = require('mongodb');

const ObjectId = dbo.ObjectId;




// Start View File Code
app.get('/', async (req, res) => {

    let database = await dbo.getDatabase();
    const collection = database.collection("products");
    const cursor = collection.find({});
    let products = await cursor.toArray();

    let message = "Hello World!"

    let notification = '';

    const status = req.query.status;

    // console.log('Status:', status);

    switch (status) {
        case '1': notification = "Product Added Successfully";
            break;

            case '3': notification = "ProductDeleted Successfully";
            break;
      
        default: break;
    }

    res.render('main', { message, products, notification, status });
});


//Add Product 

app.post('/add-product', async (req, res) => {
    let database = await dbo.getDatabase();
    const collection = database.collection("products");
    let products = { name: req.body.productName, price: req.body.price } //name & price is a collection variable name. LIKE - name:"biscuits", price:10;
    await collection.insertOne(products);

    return res.redirect('/?status=1')
})


//Edit Product

app.get('/edit-product/', async (req, res) => {

    let database = await dbo.getDatabase();
    const collection = database.collection("products");
    const cursor = collection.find({});
    let products = await cursor.toArray();

let edit_id, edit_products;

    if(req.query.edit_id){

    edit_id = req.query.edit_id;
    edit_products = await collection.findOne({_id:new ObjectId(edit_id)})

}
    let notification = '';

    const status = req.query.status;
    switch (status) {
      
        case '2': notification = "Product Updated Successfully";
            break;
        default: break;
    }
    res.render('main', { products, notification, status, edit_id, edit_products }); // This is send data to main.hbs file
});

//Update Product

app.post('/update-product/:edit_id', async (req, res) => {
    let database = await dbo.getDatabase();
    const collection = database.collection("products");
    let products = { name: req.body.productName, price: req.body.price } 
    let edit_id = req.params.edit_id;


    await collection.updateOne({_id: new ObjectId (edit_id)}, {$set: products});

    return res.redirect('/edit-product/?status=2')
})


//Delete Product

app.get('/delete-product/', async (req, res) => {

    let database = await dbo.getDatabase();
    const collection = database.collection("products");
    const cursor = collection.find({});
    let products = await cursor.toArray();

    if(req.query.delete_id){
    await collection.deleteOne({_id:new ObjectId(req.query.delete_id)})
    return res.redirect('/?status=3')
}
    let notification = '';

    const status = req.query.status;
 
    res.render('main', { products, notification, status, delete_id }); // This is send data to main.hbs file
});





// Start the server
const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
